"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const DeviceDaoFactory_1 = require("../DeviceDaoFactory");
const mongodb_1 = require("mongodb");
const mockClient = jest.fn().mockImplementation(() => {
    return {
        db: () => {
            return { collection: jest.fn() };
        },
    };
});
beforeEach(() => {
    jest.clearAllMocks();
    //mock the static MongoClient.connect here
    mongodb_1.MongoClient.connect = mockClient;
});
describe('DeviceDaoFactory.getDeviceDAO()', () => {
    test('returns a DeviceDao object', () => __awaiter(void 0, void 0, void 0, function* () {
        yield expect((0, DeviceDaoFactory_1.getDeviceDAO)()).toBeTruthy();
    }));
});
describe('DeviceDaoFactory.getUri()', () => {
    test('returns a uri with a host', () => __awaiter(void 0, void 0, void 0, function* () {
        process.env.MONGO_HOST = 'host:8001';
        yield expect((0, DeviceDaoFactory_1.getUri)()).toEqual('undefined://host:8001');
    }));
    test('returns a uri with a protocol', () => __awaiter(void 0, void 0, void 0, function* () {
        process.env.MONGO_PROTOCOL = 'mongodb';
        process.env.MONGO_HOST = undefined;
        yield expect((0, DeviceDaoFactory_1.getUri)()).toEqual('mongodb://undefined');
    }));
    test('returns a uri with a user and password', () => __awaiter(void 0, void 0, void 0, function* () {
        process.env.MONGO_PROTOCOL = 'mongodb';
        process.env.MONGO_HOST = 'host:8001';
        process.env.MONGO_USER = 'user';
        process.env.MONGO_PWD = 'pwd';
        yield expect((0, DeviceDaoFactory_1.getUri)()).toEqual('mongodb://user:pwd@host:8001');
    }));
});
//# sourceMappingURL=DeviceDaoFactory.spec.js.map