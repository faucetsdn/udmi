"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DeviceDocumentFactory_1 = require("../DeviceDocumentFactory");
const SYSTEM_SUB_FOLDER = 'system';
const MODEL_SUB_TYPE = 'model';
const STATE_SUB_TYPE = 'state';
describe('DeviceDocumentFactory.createDeviceDocument.default', () => {
    test('creates a default device document', () => {
        const inputMessage = { attributes: { deviceId: 'name', deviceNumId: 'id' }, data: {} };
        const expectedDeviceDocument = { name: 'name', id: 'id' };
        expect((0, DeviceDocumentFactory_1.createDeviceDocument)(inputMessage)).toEqual(expectedDeviceDocument);
    });
    test('creates a default device document with a timestamp', () => {
        const timestamp = '2022-04-25T17:06:12.454Z';
        const inputMessage = { attributes: { deviceId: 'name', deviceNumId: 'id' }, data: { timestamp } };
        const expectedDeviceDocument = { name: 'name', id: 'id', lastPayload: timestamp };
        expect((0, DeviceDocumentFactory_1.createDeviceDocument)(inputMessage)).toEqual(expectedDeviceDocument);
    });
});
describe('DeviceDocumentFactory.createDeviceDocument.system', () => {
    test('creates a device document with system state', () => {
        const name = 'name';
        const id = 'id';
        const make = 'make-a';
        const model = 'model-a';
        const operational = 'true';
        const serialNumber = 'serial-no';
        const firmware = 'v1';
        const inputMessage = {
            attributes: { deviceId: name, deviceNumId: id, subFolder: SYSTEM_SUB_FOLDER, subType: STATE_SUB_TYPE },
            data: {
                software: { firmware },
                hardware: { make, model },
                operational,
                serial_no: serialNumber,
            },
        };
        const expectedDeviceDocument = { name, id, make, model, operational, serialNumber, firmware };
        expect((0, DeviceDocumentFactory_1.createDeviceDocument)(inputMessage)).toEqual(expectedDeviceDocument);
    });
    test('creates a device document with system model', () => {
        const name = 'name';
        const id = 'id';
        const section = 'section-a';
        const site = 'site-a';
        const inputMessage = {
            attributes: { deviceId: name, deviceNumId: id, subFolder: SYSTEM_SUB_FOLDER, subType: MODEL_SUB_TYPE },
            data: {
                location: { section, site },
            },
        };
        const expectedDeviceDocument = { name, id, section, site };
        expect((0, DeviceDocumentFactory_1.createDeviceDocument)(inputMessage)).toEqual(expectedDeviceDocument);
    });
});
describe('DeviceDocumentFactory.isSystemState', () => {
    test('creates a default device document', () => {
        const inputMessage = { attributes: { subFolder: SYSTEM_SUB_FOLDER, subType: STATE_SUB_TYPE }, data: {} };
        expect((0, DeviceDocumentFactory_1.isSystemState)(inputMessage)).toEqual(true);
    });
    test('is not a system state', () => {
        const inputMessage = { attributes: { subFolder: SYSTEM_SUB_FOLDER, subType: 'garbage' }, data: {} };
        expect((0, DeviceDocumentFactory_1.isSystemState)(inputMessage)).toEqual(false);
    });
});
describe('DeviceDocumentFactory.isSystemModel', () => {
    test('is a system model', () => {
        const inputMessage = { attributes: { subFolder: SYSTEM_SUB_FOLDER, subType: MODEL_SUB_TYPE }, data: {} };
        expect((0, DeviceDocumentFactory_1.isSystemModel)(inputMessage)).toEqual(true);
    });
    test('is not a system model', () => {
        const inputMessage = { attributes: { subFolder: SYSTEM_SUB_FOLDER, subType: 'garbage' }, data: {} };
        expect((0, DeviceDocumentFactory_1.isSystemModel)(inputMessage)).toEqual(false);
    });
});
//# sourceMappingURL=DeviceDocumentFactory.spec.js.map