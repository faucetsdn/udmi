"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const UdmiMessageHandler_1 = require("../UdmiMessageHandler");
describe('UdmiMessageHandler', () => {
    const event = {
        attributes: {
            deviceId: 'AHU-1',
            deviceNumId: '2625324262579600',
            deviceRegistryId: 'ZZ-TRI-FECTA',
            projectId: 'labs-333619',
            subFolder: 'system',
            subType: 'model',
        },
        data: 'ewogICJsb2NhdGlvbiIgOiB7CiAgICAic2l0ZSIgOiAiWlotVFJJLUZFQ1RBIiwKICAgICJzZWN0aW9uIiA6ICIyLTNOOEMiLAogICAgInBvc2l0aW9uIiA6IHsKICAgICAgIngiIDogMTExLjAsCiAgICAgICJ5IiA6IDEwMi4zCiAgICB9CiAgfSwKICAicGh5c2ljYWxfdGFnIiA6IHsKICAgICJhc3NldCIgOiB7CiAgICAgICJndWlkIiA6ICJkcnc6Ly9UQkMiLAogICAgICAic2l0ZSIgOiAiWlotVFJJLUZFQ1RBIiwKICAgICAgIm5hbWUiIDogIkFIVS0xIgogICAgfQogIH0KfQ==',
        messageId: '4498812851299125',
        publishTime: '2022-04-25T17:05:33.162Z',
    };
    let udmiMessageHandler;
    const upsertMock = jest.fn();
    beforeEach(() => {
        udmiMessageHandler = new UdmiMessageHandler_1.default({ upsert: upsertMock });
    });
    test('Calling handleUdmiEvent invokes upsert', () => __awaiter(void 0, void 0, void 0, function* () {
        yield udmiMessageHandler.handleUdmiEvent(event);
        expect(upsertMock).toHaveBeenCalled();
    }));
    test('Exception is logged', () => __awaiter(void 0, void 0, void 0, function* () {
        // arrange
        jest.spyOn(global.console, 'error');
        upsertMock.mockImplementation(() => {
            throw Error('some error');
        });
        // act
        yield udmiMessageHandler.handleUdmiEvent(event);
        // assert
        expect(console.error).toHaveBeenCalled();
    }));
});
describe('getDocumentKey', () => {
    const deviceId = 'AHU-1';
    const deviceNumId = '2625324262579600';
    test('returns a key', () => {
        const event = {
            attributes: {
                deviceId,
                deviceNumId,
            },
            data: {},
        };
        expect((0, UdmiMessageHandler_1.getDeviceKey)(event)).toEqual({ name: deviceId, id: deviceNumId });
    });
    test('throws an exception if the deviceId is missing', () => {
        const event = {
            attributes: {
                deviceId: null,
                deviceNumId,
            },
            data: {},
        };
        expect(() => {
            (0, UdmiMessageHandler_1.getDeviceKey)(event);
        }).toThrowError('An invalid device name or id was submitted');
    });
    test('throws an exception if the deviceNumId is missing', () => {
        const event = {
            attributes: {
                deviceId,
                deviceNumId: null,
            },
            data: {},
        };
        expect(() => {
            (0, UdmiMessageHandler_1.getDeviceKey)(event);
        }).toThrowError('An invalid device name or id was submitted');
    });
});
//# sourceMappingURL=UdmiMessageHandler.spec.js.map