"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isSubType = exports.isSubFolder = exports.isSystemModel = exports.isSystemState = exports.createDeviceDocument = void 0;
const POINTSET_SUB_FOLDER = 'pointset';
const SYSTEM_SUB_FOLDER = 'system';
const MODEL = 'model';
const STATE = 'state';
function createDeviceDocument(message) {
    if (isSystemState(message)) {
        return createSystemStateDocument(message);
    }
    else if (isSystemModel(message)) {
        return createSystemModelDocument(message);
    }
    else {
        return createDefaultDeviceDocument(message);
    }
}
exports.createDeviceDocument = createDeviceDocument;
function createSystemModelDocument(message) {
    const deviceDocument = createDefaultDeviceDocument(message);
    deviceDocument.section = message.data.location.section;
    deviceDocument.site = message.data.location.site;
    return deviceDocument;
}
function createSystemStateDocument(message) {
    const deviceDocument = createDefaultDeviceDocument(message);
    deviceDocument.make = message.data.hardware.make;
    deviceDocument.model = message.data.hardware.model;
    deviceDocument.operational = message.data.operational;
    deviceDocument.serialNumber = message.data.serial_no;
    deviceDocument.firmware = message.data.software.firmware;
    return deviceDocument;
}
function createDefaultDeviceDocument(message) {
    const deviceDocument = {
        name: message.attributes.deviceId,
        id: message.attributes.deviceNumId,
    };
    if (message.data.timestamp) {
        deviceDocument.lastPayload = message.data.timestamp;
    }
    return deviceDocument;
}
function isSystemState(message) {
    return isSubFolder(message, SYSTEM_SUB_FOLDER) && isSubType(message, STATE);
}
exports.isSystemState = isSystemState;
function isSystemModel(message) {
    return isSubFolder(message, SYSTEM_SUB_FOLDER) && isSubType(message, MODEL);
}
exports.isSystemModel = isSystemModel;
function isSubFolder(message, folderName) {
    return message.attributes.subFolder === folderName;
}
exports.isSubFolder = isSubFolder;
function isSubType(message, type) {
    return message.attributes.subType === type;
}
exports.isSubType = isSubType;
//# sourceMappingURL=DeviceDocumentFactory.js.map