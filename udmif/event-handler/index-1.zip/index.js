"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleUdmiEvent = void 0;
const DeviceDaoFactory_1 = require("./DeviceDaoFactory");
const UdmiMessageHandler_1 = require("./UdmiMessageHandler");
let messageHandler;
/**
 * Triggered from a message on a Cloud Pub/Sub topic.
 *
 * @param {!Object} event Event payload.
 * @param {!Object} context Metadata for the event.
 */
const handleUdmiEvent = (event, context) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (!messageHandler) {
            console.log('Creating Message Handler');
            messageHandler = new UdmiMessageHandler_1.default(yield (0, DeviceDaoFactory_1.getDeviceDAO)());
        }
        messageHandler.handleUdmiEvent(event);
    }
    catch (e) {
        console.error('An unexpected error occurred: ', e);
    }
});
exports.handleUdmiEvent = handleUdmiEvent;
//# sourceMappingURL=index.js.map