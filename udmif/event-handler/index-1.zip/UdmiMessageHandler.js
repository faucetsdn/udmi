"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDeviceKey = exports.decodeEventData = void 0;
const DeviceDocumentFactory_1 = require("./DeviceDocumentFactory");
class UdmiMessageHandler {
    constructor(deviceDao) {
        this.deviceDao = deviceDao;
    }
    handleUdmiEvent(event) {
        try {
            const message = decodeEventData(event);
            const deviceKey = getDeviceKey(message);
            const document = (0, DeviceDocumentFactory_1.createDeviceDocument)(message);
            this.writeDocument(deviceKey, document);
        }
        catch (e) {
            console.error('An unexpected error occurred: ', e);
        }
    }
    writeDocument(key, document) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.deviceDao.upsert(key, document);
        });
    }
}
exports.default = UdmiMessageHandler;
function decodeEventData(event) {
    const stringData = Buffer.from(event.data, 'base64').toString();
    event.data = JSON.parse(stringData);
    console.debug('Decoded event: ', JSON.stringify(event));
    return event;
}
exports.decodeEventData = decodeEventData;
function getDeviceKey(message) {
    if (!message.attributes.deviceId || !message.attributes.deviceNumId) {
        throw new Error('An invalid device name or id was submitted');
    }
    return { name: message.attributes.deviceId, id: message.attributes.deviceNumId };
}
exports.getDeviceKey = getDeviceKey;
//# sourceMappingURL=UdmiMessageHandler.js.map